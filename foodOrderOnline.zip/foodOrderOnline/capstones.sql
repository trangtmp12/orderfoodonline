SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `capstones`
--

-- --------------------------------------------------------

--
-- Create `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `rest_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `payment_cd` varchar(255) NOT NULL,
  `delivery_cd` varchar(255) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `order_total` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Insert into `orders`
--

INSERT INTO `orders` (`order_id`, `rest_id`, `user_id`, `payment_cd`, `delivery_cd`, `order_date`, `order_total`) VALUES
(1, 1, 1, '1', '0', '2022-10-22 17:00:00', 20),
(2, 2, 2, '1', '0', '2022-10-25 17:00:00', 30),
(3, 3, 3, '1', '1', '2022-10-25 17:00:00', 66);

-- --------------------------------------------------------

--
-- Create `order_detail`
--

CREATE TABLE `order_detail` (
  `order_detail_id` int(11) NOT NULL,
  `rest_id` int(11) NOT NULL,
  `restaurant_item_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Insert into `order_detail`
--

INSERT INTO `order_detail` (`order_detail_id`, `rest_id`, `restaurant_item_id`, `order_id`) VALUES
(1, 1, 1, 1),
(2, 1, 2, 1),
(3, 1, 3, 1);

-- --------------------------------------------------------

--
-- Create `restaurant`
--

CREATE TABLE `restaurant` (
  `Rest_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `postal_code` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Insert into `restaurant`
--

INSERT INTO `restaurant` (`Rest_id`, `name`, `address`, `postal_code`) VALUES
(1, 'Pizza Pizza', '1 Pizza Street', 'K1K 2W3'),
(2, 'Green Fresh', '222 Arthur Street', 'K2K 3R3'),
(3, 'Lone Star', '123 March Rd', 'K2W 1C8');
(4, 'Burger King', '9923 Hunt Club Rd', 'K1W 2D8');

-- --------------------------------------------------------

--
-- Create `restaurant_item`
--

CREATE TABLE `restaurant_item` (
  `rest_item_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` double NOT NULL,
  `Rest_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Insert into `restaurant_item`
--

INSERT INTO `restaurant_item` (`rest_item_id`, `name`, `price`, `Rest_id`) VALUES
(1, 'House Special Combo ', 15, 1),
(2, 'Deluxe Pizza', 12, 1),
(3, 'Veggie Burger', 10, 2),
(4, 'Veggie Hot Dog', 9, 2),
(5, 'Miso Soup', 6, 3),
(6, 'Sushi Box', 12, 3);
(7, 'Chicken Burger', 9.90, 4);
(7, 'Double Burger', 12.70, 4);


-- --------------------------------------------------------

--
-- Create`user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `log_name` varchar(255) NOT NULL,
  `log_password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `postal_code` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Insert into `user`
--

INSERT INTO `user` (`user_id`, `first_name`, `last_name`, `log_name`, `log_password`, `email`, `address`, `postal_code`) VALUES
(1, 'John', 'Lagarde', 'jlagarde', 'password', 'jlargade@gmail.com', '2 Klondike Rd', 'K2W 1E3'),
(2, 'Gina', 'Marconi', 'gmarconi', 'password', 'gmarconi@gmail.com', '45 Garrity Crescent', 'K2J 3T4'),
(3, 'Bambi', 'Tooti', 'btooti', 'password', 'btooti@gmail.com', '145 Morrison Drive', 'K7M 5T8'),
(4, 'Bob', 'Hope', 'bhope', 'password', 'bhope@gmail.com', '298 Riley Ave', 'K7T 7T8');

--
--  ALTER TABLES
--

ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `rest_id1` (`rest_id`),
  ADD KEY `user_id` (`user_id`);

ALTER TABLE `order_detail`
  ADD PRIMARY KEY (`order_detail_id`),
  ADD KEY `rest_id2` (`rest_id`),
  ADD KEY `restaurant_item_id` (`restaurant_item_id`),
  ADD KEY `order_id1` (`order_id`);

ALTER TABLE `restaurant`
  ADD PRIMARY KEY (`Rest_id`);

ALTER TABLE `restaurant_item`
  ADD PRIMARY KEY (`rest_item_id`),
  ADD KEY `rest_item_id` (`Rest_id`);

ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);


--
-- AUTO_INCREMENT FOR PK
--
ALTER TABLE `order_detail`
  MODIFY `order_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

ALTER TABLE `restaurant`
  MODIFY `Rest_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

ALTER TABLE `restaurant_item`
  MODIFY `rest_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- CONSTRAINTS 
--

ALTER TABLE `orders`
  ADD CONSTRAINT `rest_id1` FOREIGN KEY (`rest_id`) REFERENCES `restaurant` (`Rest_id`),
  ADD CONSTRAINT `user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);

ALTER TABLE `order_detail`
  ADD CONSTRAINT `order_id1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`),
  ADD CONSTRAINT `rest_id2` FOREIGN KEY (`rest_id`) REFERENCES `restaurant` (`Rest_id`),
  ADD CONSTRAINT `restaurant_item_id` FOREIGN KEY (`restaurant_item_id`) REFERENCES `restaurant_item` (`rest_item_id`);

ALTER TABLE `restaurant_item`
  ADD CONSTRAINT `rest_item_id` FOREIGN KEY (`Rest_id`) REFERENCES `restaurant` (`Rest_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
