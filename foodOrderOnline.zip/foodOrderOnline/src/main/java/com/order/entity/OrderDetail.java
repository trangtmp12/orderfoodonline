package com.order.entity;

public class OrderDetail {

	private Integer id;
	
	private Restaurant restaurant;
	
	private RestaurantItem restaurantItem;
	
	private Order order;

	public OrderDetail() {
		
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Restaurant getRestaurant() {
		return restaurant;
	}

	public void setRestaurant(Restaurant restaurant) {
		this.restaurant = restaurant;
	}

	public RestaurantItem getRestaurantItem() {
		return restaurantItem;
	}

	public void setRestaurantItem(RestaurantItem restaurantItem) {
		this.restaurantItem = restaurantItem;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	@Override
	public String toString() {
		return "OrderDetail [id=" + id + ", restaurant=" + restaurant + ", restaurantItem=" + restaurantItem
				+ ", order=" + order + "]";
	}
	
}
