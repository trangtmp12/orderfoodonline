package com.order.entity;

import java.sql.Timestamp;

public class Order {

	private Integer id;
	private String paymentCd;
	private String deliveryCd;
	private Timestamp orderDate;
	private Double orderTotal;
	private User user;
	private Restaurant restaurant;

	public Order() {

	}

	public Order(Integer id, String paymentCd, String deliveryCd, Timestamp orderDate, Double orderTotal) {
		this.id = id;
		this.paymentCd = paymentCd;
		this.deliveryCd = deliveryCd;
		this.orderDate = orderDate;
		this.orderTotal = orderTotal;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getPaymentCd() {
		return paymentCd;
	}

	public void setPaymentCd(String paymentCd) {
		this.paymentCd = paymentCd;
	}

	public String getDeliveryCd() {
		return deliveryCd;
	}

	public void setDeliveryCd(String deliveryCd) {
		this.deliveryCd = deliveryCd;
	}

	public Timestamp getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Timestamp orderDate) {
		this.orderDate = orderDate;
	}

	public Double getOrderTotal() {
		return orderTotal;
	}

	public void setOrderTotal(Double orderTotal) {
		this.orderTotal = orderTotal;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Restaurant getRestaurant() {
		return restaurant;
	}

	public void setRestaurant(Restaurant restaurant) {
		this.restaurant = restaurant;
	}

	@Override
	public String toString() {
		return "Order [id=" + id + ", paymentCd=" + paymentCd + ", deliveryCd=" + deliveryCd + ", orderDate="
				+ orderDate + ", orderTotal=" + orderTotal + ", user=" + user + ", restaurant=" + restaurant + "]";
	}

}
