package com.order.entity;

public class User {

	private Integer id;
	private String firstName;
	private String lastName;
	private String logName;
	private String email;
	private String address;
	private String postalCode;
	private String password;

	public User() {

	}

	public User(Integer id, String firstName, String lastName, String logName, String email, String address,
			String postalCode) {
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.logName = logName;
		this.email = email;
		this.address = address;
		this.postalCode = postalCode;
	}

	public User(Integer id, String firstName, String lastName, String logName, String email, String address,
			String postalCode, String password) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.logName = logName;
		this.email = email;
		this.address = address;
		this.postalCode = postalCode;
		this.password = password;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getLogName() {
		return logName;
	}

	public void setLogName(String logName) {
		this.logName = logName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", logName=" + logName
				+ ", email=" + email + ", address=" + address + ", postalCode=" + postalCode + "]";
	}

}
