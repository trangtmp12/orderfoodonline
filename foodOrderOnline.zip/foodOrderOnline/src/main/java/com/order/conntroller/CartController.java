package com.order.conntroller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.order.entity.RestaurantItem;

@WebServlet(name = "viewcart", value = {"/viewcart"})
public class CartController extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession();
		List<RestaurantItem> list = (List<RestaurantItem>) session.getAttribute("listItem");
		Double sum = 0D;
		if(list.size()>0) {
			for(RestaurantItem r : list) {
				sum += r.getPrice()*r.getQuantity();
			}
		}
		req.setAttribute("listCart", list);
		req.setAttribute("sum", sum);
		RequestDispatcher rd = req.getRequestDispatcher("/views/viewcart.jsp");
		rd.forward(req, resp);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse resp) throws ServletException, IOException {
		
		
	}
}
