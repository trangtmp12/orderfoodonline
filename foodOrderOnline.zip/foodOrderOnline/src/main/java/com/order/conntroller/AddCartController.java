package com.order.conntroller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.order.dao.ListItemDao;
import com.order.entity.RestaurantItem;

@WebServlet(name = "addcart", value = {"/addCart"})
public class AddCartController extends HttpServlet{

	private ListItemDao listItemDao = new ListItemDao();
	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String id = req.getParameter("id");
		RestaurantItem restaurantItem = listItemDao.findById(Integer.valueOf(id));
		restaurantItem.setQuantity(1);
		HttpSession session = req.getSession();
		List<RestaurantItem> list = (List<RestaurantItem>) session.getAttribute("listItem");
		System.out.println(list);
		boolean check = false;
		if(list.size() > 0) {
			for(RestaurantItem r : list) {
				if(r.getId() == restaurantItem.getId()) {
					r.setQuantity(r.getQuantity()+1);
					check =true;
				}
			}
			if(check == false) {
				list.add(restaurantItem);
			}
		}
		else {
			list.add(restaurantItem);
		}
		session.setAttribute("listItem", list);
		resp.sendRedirect("viewcart");
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession();
		List<RestaurantItem> list = (List<RestaurantItem>) session.getAttribute("listItem");
		System.out.println(list);
		for(int i=0; i<list.size(); i++) {
			Integer quantity = Integer.valueOf(req.getParameter(list.get(i).getId().toString()));
			if(quantity == 0) {
				list.remove(i);
				--i;
			}
			else {
				list.get(i).setQuantity(quantity);
			}
		}
		resp.sendRedirect("viewcart");
	}
}
