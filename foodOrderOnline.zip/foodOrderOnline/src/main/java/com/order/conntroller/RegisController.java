package com.order.conntroller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.order.dao.UserDao;
import com.order.entity.User;

@WebServlet(name = "regis", value = { "/regis" })
public class RegisController extends HttpServlet {

	private UserDao userDao = new UserDao();
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		RequestDispatcher rd = req.getRequestDispatcher("/views/regis.jsp");
		rd.forward(req, resp);
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		User user = new User(null, req.getParameter("firstname"), req.getParameter("lastname"),
				req.getParameter("user"), req.getParameter("email"), req.getParameter("address"),
				req.getParameter("postcode"), req.getParameter("pass"));
		if(userDao.save(user)) {
			resp.sendRedirect("login");
			System.out.println("resgis user success: "+user);
		}
		else {
			resp.sendRedirect("regis?error=1");
		}
		
	}
}
