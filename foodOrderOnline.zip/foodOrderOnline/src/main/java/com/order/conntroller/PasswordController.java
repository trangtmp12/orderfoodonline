package com.order.conntroller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.order.dao.UserDao;

@WebServlet(name = "lostpassword", value = {"/lostpassword"})
public class PasswordController extends HttpServlet{

	private UserDao userDao = new UserDao();
	
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		RequestDispatcher rd = req.getRequestDispatcher("/views/lostpassword.jsp");
		rd.forward(req, resp);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse resp) throws ServletException, IOException {
		String password = userDao.getPassword(request.getParameter("email"));
		resp.sendRedirect("lostpassword?pass="+password);
	}
}
