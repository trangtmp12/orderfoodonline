package com.order.conntroller;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.order.dao.OrderDao;
import com.order.dao.RestaurantDao;
import com.order.entity.Order;
import com.order.entity.OrderDetail;
import com.order.entity.RestaurantItem;
import com.order.entity.User;

@WebServlet(name = "confirm", value = { "/confirm" })
public class ConfirmController extends HttpServlet {
	private RestaurantDao restaurantDao = new RestaurantDao();
	private OrderDao orderDao = new OrderDao();
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession();
		List<RestaurantItem> list = (List<RestaurantItem>) session.getAttribute("listItem");
		Double sum = 0D;
		if (list.size() > 0) {
			for (RestaurantItem r : list) {
				sum += r.getPrice() * r.getQuantity();
			}
		}
		req.setAttribute("listCart", list);
		req.setAttribute("sum", sum);
		req.setAttribute("time", new Timestamp(System.currentTimeMillis()));
		Order order = orderDao.findMaxId();
		req.setAttribute("Payment", order.getPaymentCd());

		req.setAttribute("Delivery", order.getDeliveryCd());
		System.out.println(order);
		RequestDispatcher rd = req.getRequestDispatcher("/views/confirm.jsp");
		rd.forward(req, resp);
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession();
		List<RestaurantItem> list = (List<RestaurantItem>) session.getAttribute("listItem");
		Double sum = 0D;
		if (list.size() > 0) {
			for (RestaurantItem r : list) {
				sum += r.getPrice() * r.getQuantity();
			}
		}
		req.setAttribute("listCart", list);
		req.setAttribute("sum", sum);
		req.setAttribute("time", new Timestamp(System.currentTimeMillis()));
		User user = (User) session.getAttribute("user");

		Order order = new Order(null, req.getParameter("Payment"), req.getParameter("Delivery"),
				new Timestamp(System.currentTimeMillis()), sum);
		order.setUser(user);
		List<OrderDetail> listOrderDetail = new ArrayList<OrderDetail>();
		if (list.size() > 0) {
			for (RestaurantItem r : list) {
				OrderDetail orderDetail = new OrderDetail();
				orderDetail.setOrder(order);
				orderDetail.setRestaurantItem(r);
				orderDetail.setRestaurant(restaurantDao.findByResItemId(r.getId()));
				listOrderDetail.add(orderDetail);
			}
			orderDao.save(order, listOrderDetail);
		}

		resp.sendRedirect("confirm");
	}
}
