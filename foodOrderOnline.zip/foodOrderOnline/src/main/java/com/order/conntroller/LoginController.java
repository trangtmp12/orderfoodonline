package com.order.conntroller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.order.dao.LoginDao;
import com.order.entity.RestaurantItem;
import com.order.entity.User;

@WebServlet(name = "login", value = {"/","/login"})
public class LoginController extends HttpServlet{

	private LoginDao loginDao = new LoginDao();
	
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		RequestDispatcher rd = req.getRequestDispatcher("/views/login.jsp");
		rd.forward(req, resp);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse resp) throws ServletException, IOException {
		String logname = request.getParameter("username");
		String password = request.getParameter("password");
		User user = loginDao.login(logname, password);
		if(user != null) {
			List<RestaurantItem> list = new ArrayList<RestaurantItem>();
			System.out.println(user);
			HttpSession session = request.getSession();
			session.setAttribute("user", user);
			session.setAttribute("listItem", list);
			resp.sendRedirect("listRestaurant");
			System.out.println("insert user to session: "+(User)session.getAttribute("user"));
		}
		else {
			resp.sendRedirect("login?error=1");
		}
	}
}
