package com.order.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import com.order.connect.Connect;
import com.order.entity.Order;
import com.order.entity.OrderDetail;

public class OrderDao {
	
	private Connect connect = new Connect();
	private Connection conn = null;
	private PreparedStatement pre = null;
	private ResultSet res = null;
	
	public void save(Order order, List<OrderDetail> list) {
		String sql_order = "insert into orders(rest_id,user_id,payment_cd,delivery_cd,order_date,order_total) values (?,?,?,?,?,?)";
		String sql_detail = "insert into order_detail (rest_id ,restaurant_item_id ,order_id) values (?,?,?)";
		conn = connect.getConnectionToDatabase();
		int id_order = -1;
		order.setRestaurant(list.get(0).getRestaurant());
		try {
			pre = conn.prepareStatement(sql_order,
                    Statement.RETURN_GENERATED_KEYS);
			pre.setInt(1, order.getRestaurant().getId());
			pre.setInt(2, order.getUser().getId());
			pre.setString(3, order.getPaymentCd());
			pre.setString(4, order.getDeliveryCd());
			pre.setTimestamp(5, order.getOrderDate());
			pre.setDouble(6, order.getOrderTotal());
			pre.executeUpdate();
			
			try (ResultSet generatedKeys = pre.getGeneratedKeys()) {
	            if (generatedKeys.next()) {
	                id_order = generatedKeys.getInt(1);
	            }
	            else {
	                throw new SQLException("Creating user failed, no ID obtained.");
	            }
	        }
			System.out.println(id_order);
			for(OrderDetail o : list) {
				pre = conn.prepareStatement(sql_detail);
				pre.setInt(1, o.getRestaurant().getId());
				pre.setInt(2, o.getRestaurantItem().getId());
				pre.setInt(3, id_order);
				pre.executeUpdate();
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public Order findMaxId() {
		String sql = "SELECT * FROM orders WHERE order_id = (select max(order_id) from orders)";
		conn = connect.getConnectionToDatabase();
		try {
			pre = conn.prepareStatement(sql);
			res = pre.executeQuery();
			if(res.next()) {
				Order order = new Order();
				order.setDeliveryCd(res.getString("delivery_cd"));
				order.setPaymentCd(res.getString("payment_cd"));
				return order;
			}
		} catch (SQLException e) {
			return null;
		}
		return null;
	}
}
