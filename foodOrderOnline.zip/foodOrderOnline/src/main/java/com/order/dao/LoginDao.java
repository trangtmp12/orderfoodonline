package com.order.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.order.connect.Connect;
import com.order.entity.User;

public class LoginDao {

	private Connect connect = new Connect();
	private Connection conn = null;
	private PreparedStatement pre = null;
	private ResultSet res = null;

	public User login(String log_name, String password) {
		String sql = "select * from user where log_name = ? and log_password = ?";
		conn = connect.getConnectionToDatabase();
		try {
			pre = conn.prepareStatement(sql);
			pre.setString(1, log_name);
			pre.setString(2, password);
			res = pre.executeQuery();
			if (res.next()) {
				User user = new User(res.getInt("user_id"), res.getString("first_name"), res.getString("last_name"),
						res.getString("log_name"), res.getString("email"), res.getString("address"),
						res.getString("postal_code"));
				return user;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
}
