package com.order.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.order.connect.Connect;
import com.order.entity.User;

public class UserDao {

	private Connect connect = new Connect();
	private Connection conn = null;
	private PreparedStatement pre = null;
	private ResultSet res = null;
	
	public boolean save(User user) {
		String sql = "insert into user(first_name, last_name,log_name,log_password,email,address,postal_code) values(?,?,?,?,?,?,?)";
		conn = connect.getConnectionToDatabase();
		try {
			pre = conn.prepareStatement(sql);
			pre.setString(1, user.getFirstName());
			pre.setString(2, user.getLastName());
			pre.setString(3, user.getLogName());
			pre.setString(4, user.getPassword());
			pre.setString(5, user.getEmail());
			pre.setString(6, user.getAddress());
			pre.setString(7, user.getPostalCode());
			return pre.executeUpdate()>0;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public String getPassword(String email) {
		String sql = "select log_password from user where email = ?";
		conn = connect.getConnectionToDatabase();
		try {
			pre = conn.prepareStatement(sql);
			pre.setString(1, email);
			res = pre.executeQuery();
			if (res.next()) {
				return res.getString("log_password");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return "";
	}
}
