package com.order.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.order.connect.Connect;
import com.order.entity.Restaurant;

public class RestaurantDao {

	private Connect connect = new Connect();
	private Connection conn = null;
	private PreparedStatement pre = null;
	private ResultSet res = null;

	public List<Restaurant> findAll() {
		List<Restaurant> list = new ArrayList<Restaurant>();
		String sql = "select * from restaurant";
		conn = connect.getConnectionToDatabase();
		try {
			pre = conn.prepareStatement(sql);
			res = pre.executeQuery();
			while (res.next()) {
				Restaurant restaurant = new Restaurant(res.getInt("Rest_id"), res.getString("name"),
						res.getString("address"), res.getString("postal_code"));
				list.add(restaurant);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public Restaurant findById(Integer id) {
		String sql = "select * from restaurant where Rest_id =?";
		conn = connect.getConnectionToDatabase();
		try {
			pre = conn.prepareStatement(sql);
			pre.setInt(1, id);
			if (res.next()) {
				Restaurant restaurant = new Restaurant(res.getInt("Rest_id"), res.getString("name"),
						res.getString("address"), res.getString("postal_code"));
				return restaurant;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public Restaurant findByResItemId(Integer resid) {
		String sql = "select r.* from restaurant r inner join restaurant_item ri on ri.Rest_id = r.Rest_id where ri.rest_item_id = ?";
		conn = connect.getConnectionToDatabase();
		try {
			pre = conn.prepareStatement(sql);
			pre.setInt(1, resid);
			res = pre.executeQuery();
			if (res.next()) {
				Restaurant restaurant = new Restaurant(res.getInt("Rest_id"), res.getString("name"),
						res.getString("address"), res.getString("postal_code"));
				return restaurant;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}
