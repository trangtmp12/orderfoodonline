package com.order.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.order.connect.Connect;
import com.order.entity.RestaurantItem;

public class ListItemDao {

	private Connect connect = new Connect();
	private Connection conn = null;
	private PreparedStatement pre = null;
	private ResultSet res = null;

	public List<RestaurantItem> findByResId(Integer resId) {
		List<RestaurantItem> list = new ArrayList<RestaurantItem>();
		String sql = "select * from restaurant_item where Rest_id = ?";
		conn = connect.getConnectionToDatabase();
		try {
			pre = conn.prepareStatement(sql);
			pre.setInt(1, resId);
			res = pre.executeQuery();
			while (res.next()) {
				RestaurantItem restaurantItem = new RestaurantItem(res.getInt("rest_item_id"), res.getString("name"),
						res.getDouble("price"));
				list.add(restaurantItem);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public RestaurantItem findById(Integer id) {
		String sql = "select * from restaurant_item where rest_item_id = ?";
		conn = connect.getConnectionToDatabase();
		try {
			pre = conn.prepareStatement(sql);
			pre.setInt(1, id);
			res = pre.executeQuery();
			if (res.next()) {
				RestaurantItem restaurantItem = new RestaurantItem(res.getInt("rest_item_id"), res.getString("name"),
						res.getDouble("price"));
				return restaurantItem;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
}
