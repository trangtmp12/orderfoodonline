package com.order.connect;

import java.sql.Connection;
import java.sql.DriverManager;

public class Connect {

	  public static Connection getConnectionToDatabase() {
			Connection connect = null;
			try {
		        try {
		            Class.forName("com.mysql.jdbc.Driver");
		            connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/capstones", "root", "Danang2018@");
		        } catch (Exception ex) {
		            ex.printStackTrace();
		        }
	        } catch (Exception ex) {
	            ex.printStackTrace();
	        }
			return connect;
		}
		
	  public static void main(String[] args) {
		System.out.println(getConnectionToDatabase());
	}
}
